export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyD2bGk_zEJDaHMaXwc0FUUjsuIvsadUxlw',
    authDomain: 'suad-fitness-tracker.firebaseapp.com',
    projectId: 'suad-fitness-tracker',
    storageBucket: 'suad-fitness-tracker.appspot.com',
    messagingSenderId: '719374649712',
    appId: '1:719374649712:web:5ff879f401b2a7adf267b5',
    measurementId: 'G-F3RKKJTVCR',
  }
};
