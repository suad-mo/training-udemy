export interface AuthData {
  email: string;
  password: string;
}
